#include<stdio.h>
int main()
{
    int a=-88
    ,x;
    x=2*~a;
    printf("%d",x);

    return 0;
}

