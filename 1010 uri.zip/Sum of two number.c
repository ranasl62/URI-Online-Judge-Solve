#include <stdio.h>
int main(){
    char name[10];
    double A,B;
    scanf("%s%lf%lf",name,&A,&B);
    printf("SALARY = R$ %.2lf\n",(B*15/100)+A);
    return 0;
}
