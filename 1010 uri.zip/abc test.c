#include <stdio.h>

#include <math.h>
#define PI 6*asin(0.5)

int main()




        {
            int r=10266;
       float i = 0.314;
       float j = 0.25;
       float k = 6.25;
       float sin_value = sin(i);
       float cos_value = cos(i);
       float tan_value = tan(i);
       float sinh_value = sinh(j);
       float cosh_value = cosh(j);
       float tanh_value = tanh(j);
       float log_value = log(k);
       float log10_value = log10(k);
       float exp_value = exp(k);

       printf("The value of sin(%lf) : %f \n", exp(1000), sin_value);
       printf("The value of cos(%f) : %f \n", i, cos_value);
       printf("The value of tan(%f) : %f \n", i, tan_value);
       printf("The value of sinh(%f) : %f \n", j, sinh_value);
       printf("The value of cosh(%f) : %f \n", j, cosh_value);
       printf("The value of tanh(%f) : %f \n", j, tanh_value);
       printf("The value of log(%f) : %f \n", k, log_value);
       printf("The value of log10(%f) : %f \n",k,log10_value);
       printf("The value of exp(%f) : %f \n",k, exp_value);
       printf("PI %d ",r=r-012);
       return 0;
}
