///"ac" "ad" "bb" "bc" "bd" "cb" "cc" "cd" "db
#include<stdio.h>
int main()
{
    int i,j,k;
    for(i=1;i<=9;i++)
    printf("\"%c%c\" ",i%10/3+97,i%3+98);





}
