#include<stdio.h>
void main()
{
    int a,b,c;
    a=36;
    b=2;
    c = b[2];
    printf("%d",c);
}





