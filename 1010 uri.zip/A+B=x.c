#include <stdio.h>

int main (void)

{   int number1,number2,result;

    printf("enter the number \n");

    scanf("%d",&number1);
    scanf("%d", &number2);

    result = number1 + number2;

    printf("then Result is %d",result);

    return 0;

}
