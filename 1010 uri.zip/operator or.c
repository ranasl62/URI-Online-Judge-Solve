#include<stdio.h>
int main()
{
    int a, b , c;

    a=5;

    b=5;

    c = a || b

    printf("%d",c);

    return 0;
    }
