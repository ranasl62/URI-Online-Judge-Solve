#include<stdio.h>

int main ()

{
    float a,c;
    float b;
    printf("Enter the two number\n");
    scanf("%f", &a);
    scanf("%f", &b);
    printf("%f",c);
    return 0;
    }
