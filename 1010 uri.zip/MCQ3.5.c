
#include<stdio.h>
int main()
{
    int X,b=-7;;
    X=b>8 ? b<<3 : b>4 ? b>>1 : b>>2;
    printf("%d",sizeof(long));

    return 0;
}
