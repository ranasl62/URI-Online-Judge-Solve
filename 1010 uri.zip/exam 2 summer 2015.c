
#include<stdio.h>
int main()
{
    int a,b,c;
    printf("Enter the number : ");
   scanf("%d",&a);
   if(a%2==0)
    printf("\nThe number is Special\n");
   else
   printf("\nThe number is not Special\n");

}
