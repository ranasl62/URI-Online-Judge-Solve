#include<stdio.h>
#define PI 3.1416
#define PR 5
int main()
{
    int i =8, j =5 , t;
    float x = .0005, y = -0.01,f;
    char c = 'c', d = 'd';
    t=PR*PI;
    PR=t;
    t=PR;
    printf("%d",t);
}
