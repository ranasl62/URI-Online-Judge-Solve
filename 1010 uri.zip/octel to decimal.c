#include<stdio.h>
int main()
{

  long int decimalNumber;

  printf("Enter any decimal number  :");
  scanf("%o",&decimalNumber);printf("CM");


  printf("\nEquivalent octal number is: %d\n",decimalNumber);

  return 0;
}

