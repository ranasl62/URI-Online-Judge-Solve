#include<stdio.h>
int main(void)
{
double i,k,l=1,m,n=0,p;
scanf("%lf",&p);
   for(i=1;i<=p;i++)
   {    k=i*i;
       l=l*i;
       m=k/l;
       n=n+m;
   }
        printf("%lf",n);
}
