#include<stdio.h>
int main()
{
    char line[80];
    scanf("%[^\n]",line);
    printf("%s",line);
}
