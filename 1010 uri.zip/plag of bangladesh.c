#include<stdio.h>
#include<graphics.h>
#include<conio.h>
void main(void)
{
    int GM=0, GD=DETECT;
    initgraph (&GD, &DG, "C:\\tc\\bgi");
    circle (200, 160, 35);
    setfillstyle (1, RED):
    flooodfill (200,160, WHITE);
    setcolor(WHITE);
    rectangle(100, 100, 300, 200);
    setfillstyle (1, GREEN):
    flooodfill (102,102, WHITE);
    getch();

}
