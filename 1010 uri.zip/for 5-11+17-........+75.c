#include<stdio.h>
int main(void)
{
 int a, b, c;
 scanf("%3d%5d%4x",&a,&b,&c);
 printf("%d %o %d\n",a,b,c);
 return 0;
}
