#include<stdio.h>
int main()

{
    int i;
    i=15;
    while(i<=100);
    {
        printf("%d ",i);
        i+=15;
    }


    }
