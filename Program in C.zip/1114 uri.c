#include<stdio.h>
int main()
{
    int a;
    while(scanf("%d",&a))
    {
        if(a==2002)
        {
            printf("Acesso Permitido\n");
        return 0;
        }
        else
        printf("Senha Invalida\n");
    }
}
