 ///acd acd acd acd

#include<stdio.h>
int main(void)
{
int i,k;


for(i=0;i<=20;i++)
{
    k=0;
    if (i%3==2)
        k=-1;
    printf("%c\n",i%3*2+97+k);

}








}
