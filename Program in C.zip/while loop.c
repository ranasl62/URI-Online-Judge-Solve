#include<stdio.h>
int main(void)
{
    int i=77;
 while(i>=42)
 {
     printf("%d\n",i);
     i-=7;
 }



}



