#include<stdio.h>
#include<math.h>
int main(void)
{
    char b[50]="america";
int a=03321;
printf(" %d ",--a);
printf(" %d ",sizeof(long  double
                     ));
printf(" %lf ",log10(5));
printf(" %d ",a+a/2/2);
}
