/*Suppose, there are 3 tests Bangla,English and math.Take the scores of each test as Input from user.
Calculate the Average number of 3 score.
Task-1. Print the average number.
Task-2. Calculate the grade on the basis of the Avg. Number.
Show the grade of the student using following chart
A -> 80 to 100
B -> 60 to 79
C -> 50 to 59
F -> below 50
[hint: Use floating point number.]*/
#include<stdio.h>
int main()
{
    float Bangla, English, Math,Average;
    printf("Enter the number of Bngala :");
    scanf("%f",&Bangla);
    printf("\nEnter the number of English : ");
    scanf("%f",&English);
    printf("\nEnter the number of Math :");
    scanf("%f",&Math);
    Average=(Bangla+English+Math)/3;
    printf("\nThe average score : %.2f \n",Average);
    if(Average >= 80)
        printf("\n***You got A grade***\n");
    else if(Average >= 60)
        printf("\n***You got B grade***\n");
    else if(Average >= 50)
        printf("\n***You got C grade***\n");
    else
        printf("\n***You got F grade***\n");
        return 0;
}
