#include<stdio.h>
int main(void)
{
    int i=100;
 while(i>=60)
 {
     printf("%d\n",i);
     i-=10;
 }



}



