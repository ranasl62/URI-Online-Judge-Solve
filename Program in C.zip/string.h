#include<stdio.h>
int main()
{
    char s[100],s1[100],temp[100];
    scanf("%s%s",s,s1);

    printf("%s%s",s,s1);
}
