#include<stdio.h>
int main()
{
    printf("%d",sizeof(float));
}
