#include<stdio.h>

int main()
{
   int math, physics, ck;
   math=5;
   physics=5;
   ck= math==5 && physics==5;
   printf("%d\n",ck);
   ck= !(math==5);
   printf("%d\n",ck);
   ck = math==5 II physics==5;
   printf("%d",ck);

    return 0;
}
