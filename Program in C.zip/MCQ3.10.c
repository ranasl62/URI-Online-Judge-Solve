#include<stdio.h>
int main()
{
    int x ,y,f;
    f=(x>y)?x:y;
    printf("\n%d",!!3+1);

    return 0;
}

