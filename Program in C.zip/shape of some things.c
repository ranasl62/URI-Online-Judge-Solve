#include<stdio.h>
int main()
{
    int i,j,k,l,m;
    scanf("%d",&m);
    for(i=1; i<=m; i++)
    {

        for(j=1; j<=i*2-1; j++)
            printf("*");


        printf("\n");
    }
}
