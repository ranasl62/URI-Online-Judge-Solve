#include<stdio.h>
int main()
{
    int x,i,a;
    scanf("%d",&x);
    for( i = 0; i < x; i++)
       {
        scanf("%d",&a);
        {
            if(a == 0)
                printf("NULL\n");
            else
            {
            if(a%2 == 0)
            {
                if(a<0)
                printf("EVEN NEGATIVE\n");
                else
                    printf("EVEN POSITIVE\n");
            }
            else
            {
                if(a>0)
                printf("ODD POSITIVE\n");
                else
                    printf("ODD NEGATIVE\n");
            }
            }
}
       }
    return 0;
}

