#include<stdio.h>

int main()
{
    double A,R,PI;
    scanf("%lf", &R);
    PI=3.14159;
    A = PI*R*R;
    printf("A=%.4lf\n",A);
    return 0;
}
