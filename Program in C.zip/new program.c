#include<stdio.h>
int main()
{
    int a=5;
    printf("%d %d ",a++,a--);
    printf("%d",a);
}
