#include<stdio.h>

int main()
{
    int x;
    float y,z;
    scanf("%d\n %f",&x,&y);
    z=x/y;
    printf("%.3f km/l\n",z);
    return 0;
}
