#include<stdio.h>
int main()
{
    int a,c=5;
    a=++c + ++c;
    cout<<a;

    return 0;
}
