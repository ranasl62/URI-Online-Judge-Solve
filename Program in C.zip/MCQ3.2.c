#include<stdio.h>
int main()
{

    printf("%d",'a');

    return 0;
}
