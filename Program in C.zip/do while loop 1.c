#include<stdio.h>
int main(void)
{
    int i=1,j=1;
 do
 {
     printf("%d\n",i);
     i+=j;
     j++;

 }while(j<=8);



}



