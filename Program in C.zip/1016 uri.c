#include<stdio.h>
int main()
{
      int t,v;
      scanf("%d\n%d",&t,&v);
      printf("%.3f\n",(float)(t*v)/12);
      return 0;
}
