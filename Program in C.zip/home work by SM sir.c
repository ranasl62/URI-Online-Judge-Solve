 ///9753 9753 9753 9753 9753
#include<stdio.h>
int main(void)
{
int i;
for(i=0;i<=20;i++)
{
    printf("%d\r\n",-i%4*2+9);

}
}
