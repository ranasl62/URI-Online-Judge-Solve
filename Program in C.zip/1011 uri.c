#include<stdio.h>
int main()
{
    int r;
    double v,pi=3.14159;
    scanf("%d",&r);
    v=(4/3.0)*pi*r*r*r;
    printf("VOLUME = %.3lf\n",v);
}
