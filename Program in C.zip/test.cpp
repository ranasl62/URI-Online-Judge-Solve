#include <iostream>
using namespace std;
int main()
{
    int HA, OA;

    while (cin >> HA >> OA)
    {
        if (HA > OA)
            cout << HA - OA << endl;
        else
            cout << OA - HA << endl;
    }

    return 0;
}
