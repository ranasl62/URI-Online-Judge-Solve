#include<stdio.h>
int main()
{
    int x[5],y1,y2,i,X;
    scanf("%d",&X);
    x[0]=X/100;
    x[1]=X%10;
    x[2]=X/10;
    x[3]=x[2]%10;
    x[4]=X%100;
    y1=x[0]*x[3];
    y2=x[1]*x[3];
    X=0;
    for(i=0; i<5; i++)
        if(y1==x[i]||y2==x[i])
            X++;
    if(X)
        printf("The number is  not colored number\n");
    else
        printf("The number is  colored number \n");

}

