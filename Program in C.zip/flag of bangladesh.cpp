#include<stdio.h>
#include<graphics.h>
#include<conio.h>
using namespace std;
int main(void)
{
    int GM=0,GD=DETECT;

}
