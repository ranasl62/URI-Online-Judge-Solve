#include<stdio.h>
int main(void)
{
 printf("Has%s%.1s Has%.2s %c+\n","are","yes","arc",65);
 printf("%.2sra %.3s%.2s %3.4s ei Queen%s e",
 "America","Sober","air","rajakar","dom\0estic");
}



