#include<stdio.h>
int main()
{
    int i=10;
    char a[10]="20";
    printf("%d",a[i]=i++);

    return 0;
}
