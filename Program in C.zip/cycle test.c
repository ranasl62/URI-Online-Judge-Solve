/// 9 7 5 3
#include<stdio.h>
int main(void)
{
int i;
for(i=0;i<=4;i++)

{
printf("%d\n",(i%4)*-2+9);

}
}
