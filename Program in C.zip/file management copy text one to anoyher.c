#include<stdio.h>
int main()
{
    char ch[100];
    FILE *ps,*ps1,*ps2;
    ps=fopen("rana.txt","w");
    scanf("%s",ch);
    fprintf(ps,"%s",ch);
    fclose(ps);
    ps1=fopen("rana1.txt","w");
    fscanf(ps,"%s",ch);
    fprintf(ps1,"%s",ch);
    ps1=fopen("rana1.text","r");
    fscanf(ps1,"%s",ch);
    printf("%s\n",ch);
    fclose(ps1);

}
