#include<stdio.h>
int main()
{
    int i;
    for(i=0;i<14;i++)
    {
        printf("%d ",i/3*2+10);
    }
    return 0;
}
