#include<stdio.h>
int main()
{
char ch= 291;
printf("%d %d %c", 32770, ch, ch);
}
