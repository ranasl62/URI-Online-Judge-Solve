#include<stdio.h>

int main()
{
    int a,b,d,c;
    a=5,b=6,d=2;
    c=a<b;
    printf("%d\n",c);
    c=a>d;
    printf("%d\n",c);
    c=b>d;
    printf("%d\n",c);
    c=a!=b;
    printf("%d\n",c);
    c=a==b;
    printf("%d\n",c);
    c=a=b;
    printf("%d\n",c);
    return 0;
}
