#include<stdio.h>
int main()
{
    int a, b,c ;

    a=5;

    b=10;

    c=

    ( a > b ) ? printf("%d true\n",a) : printf("%dfalse\n",b+1);

    return 0;
    }
