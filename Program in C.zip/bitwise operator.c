#include<stdio.h>
int main()
{
    int a, b ;

    a=5;

    b=6;

    printf("%d %d %d\n" ,a&b ,a|b, a^b);

    a=25;

    printf("%d\n%d " ,a>>1,a<<1);


    return 0;
    }
