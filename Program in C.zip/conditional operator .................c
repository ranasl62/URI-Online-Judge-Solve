#include<stdio.h>
int main ()

{
    int a,b,c;

    printf("Enter the number\n");

    scanf("%d",&a);

    scanf("%d",&b);

    scanf("%d",&c);
    if (a>b)
    {
        if (a>c)
            printf("The largest number is a");
        else
            printf("The largest number is c");
    }
    else
    {
        if (b>c)
            printf("The largest number is b");
        else
            printf("The largest number is c");

    }

    return 0;
}

