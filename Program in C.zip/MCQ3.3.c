#include<stdio.h>
int main()
{
    int a=1000,b=1000;
    long int c;
    c=a*b;
    printf("%ld",c);

    return 0;
}
